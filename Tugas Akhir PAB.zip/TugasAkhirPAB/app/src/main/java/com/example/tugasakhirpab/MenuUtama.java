package com.example.tugasakhirpab;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MenuUtama extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_utama);
    }
}